/* Author:

*/
//replace no-js classs on html tag with js
d=document.documentElement;
d.className=d.className.replace(/\bno-js\b/,'') + ' js';